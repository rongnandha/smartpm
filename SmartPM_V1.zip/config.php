<?php

	$line_token = 'LINETOKEN';

	$netpie_app_id = 'NETPIEAPPID';
	
	$netpie_key = 'NETPIEKEY';

	$netpie_secret = 'NETPIESECRET';

	$netpie_device_name = 'NETPIEDEVICENAME';

?>